<template>
  <div style="background-color:  #F5F5F7">

    <div style="height: 50px"></div>

    <!--展示内容-->
    <div style="width: 80%;margin: 0 12%;">
      <div style="height: 610px">

        <el-scrollbar style="height: 100%;width: 100%;">
          <div v-for="(item,index) in tableData">
            <!--论文内容-->
            <MyNote v-bind:item="item"></MyNote>
          </div>
        </el-scrollbar>
      </div>
    </div>
    <!--展示内容-->
    <div style="height: 20px"></div>
    <!--分页-->
    <div style="width: 60%;margin-left: 20%">
      <el-pagination style="margin: 0 auto"
                     v-model:currentPage="currentPage4"
                     v-model:page-size="pageSize4"
                     :page-sizes="[5, 10, 15 , 20]"
                     layout="total, sizes, prev, pager, next, jumper"
                     :total="400"
                     @size-change="handleSizeChange"
                     @current-change="handleCurrentChange"
      />
    </div>
    <!--分页-->



    <el-drawer
        title="我是标题"
        :visible.sync="drawer"
        :direction="direction"
        :close="handleClose">
      <span>我来啦!</span>
    </el-drawer>


  </div>

</template>

<script>
import MyNote from "@/components/MyNote";
export default {
  name: "MyNotes",
  components: {MyNote},
  data(){
    return{
      drawer:false,
      direction:'rtl',
      tableData:[
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          content:'笔记内容：以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤',
          upDate:'2022-02-02'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          content:'笔记内容：以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤',
          upDate:'2022-02-02'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          content:'笔记内容：以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤',
          upDate:'2022-02-02'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          content:'笔记内容：以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤',
          upDate:'2022-02-02'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          content:'笔记内容：以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤',
          upDate:'2022-02-02'
        }
      ],
      currentPage4:1,
      pageSize4:3,
    }
  },
  methods:{
    handleSizeChange(){

    },
    handleCurrentChange(){

    },
    showData(e){
      this.drawer=true;
      console.log(e)
    },
    handleClose() {
      this.drawer=false;
    }

  }
}
</script>

<style scoped>


</style>