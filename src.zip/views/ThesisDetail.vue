<template>

  <div style="background-color: #F5F5F7">

    <div style="width: 90%;margin: 0 5%; ">
      <div style="height: 40px"></div>
      <div class="card">
        <div class="card__content" style="padding-left: 10px;padding-right: 10px">
          <div style="height: 5px"></div>
                    <div style="font-weight: bold;margin-top: 10px;">标题：{{thesisContent.title}}</div>
                    <div style="height: 5px"></div>
                    <div style=";color: #8c939d">
                      <div style="display: inline-block;width: 25%">作者：{{thesisContent.author}}</div>
                      <div style="display: inline-block;width: 25%">会议：{{thesisContent.meeting}}</div>
                      <div style="display: inline-block;width: 25%">出版时间：{{thesisContent.date}}</div>
                      <div style="display: inline-block;width: 25% ">论文类型：{{thesisContent.type}}</div>
                    </div>
                    <div style="height: 5px"></div>
                    <div><span style="font-weight: bold">摘要：</span>{{thesisContent.abstract}}</div>
                    <div>引用文章：{{thesisContent.quotation}}</div>
                    <div style="height: 5px"></div>
                    <div style="color: #8c939d">
                      <div style="width: 50%;display: inline-block">上传用户：{{thesisContent.uploader}}</div>
                      <div style="width: 50%;display: inline-block">上传时间：{{thesisContent.uploadDate}}</div>
                    </div>
                    <div style="height: 5px"></div>
        </div>
      </div>

      <!--笔记内容-->
      <div id="note-content">
        <el-scrollbar  style="height: 100%">
          <p>
            {{note}}
          </p>
        </el-scrollbar>

      </div>
      <!--笔记内容-->
      <div style="height: 2px"></div>
      <div>

        <div style="display: inline-block;width: 89%">
          <button id="find_file"> 查看附件
          </button>
        </div>

        <div style="display: inline-block;width:11%">
          <button id="comment-btn" @click="centerDialogVisible=!centerDialogVisible">
            <span>查看评论</span>
          </button>

        </div>


      </div>

      <!--评论区-->




    </div>
    <el-dialog
        title="评论"
        :visible.sync="centerDialogVisible"
        width="60%"
        center>

      <CommentAdd />
      <CommentList />

      <span slot="footer" class="dialog-footer">
    <el-button @click="centerDialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="centerDialogVisible = false">确 定</el-button>
  </span>
    </el-dialog>

  </div>


</template>

<script>
import CommentAdd from '../components/CommentAdd.vue'
import CommentList from '../components/CommentList.vue'

export default {
  name: "ThesisDetail",
  components:{
    CommentAdd,
    CommentList
  },
  data(){
    return{
      centerDialogVisible: false,
      thesisContent:{
        title:'自然语言处理新范式：基于预训练模型的方法',
        author:'车万翔 刘挺',
        meeting:'中兴通讯技术',
        date:'2016-05-02',
        type:'计算机软件及计算机应用',
        abstract:'以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
            '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
            '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
            '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
        uploader:'刘大锤',
        quotation:'自然语言处理的应用',
        uploadDate:'2022-2-2'
      },
      note:'病例1—病例33，居住于浦东新区，病例34，居住于黄浦区，病例35—病例39，居住于徐汇区，病例40、病例41，居住于长宁区，病例42—病例50，居住于静安区，病例51—病例53，居住于普陀区，病例54—病例56，居住于虹口区，病例57—病例62，居住于杨浦区，病例63—病例65，居住于闵行区，病例66—病例81，居住于宝山区，病例82—病例108，居住于松江区，均为上海市闭环隔离管控人员，其间新冠病毒核酸检测结果异常，经疾控中心复核结果为阳性。经市级专家会诊，综合流行病学史、临床症状、实验室检测和影像学检查结果等，诊断为确诊病例。\n' +
          '\n' +
          '病例109，居住于松江区，在风险人群筛查中发现新冠病毒核酸检测结果异常，即被隔离管控。经疾控中心复核结果为阳性。经市级专家会诊，综合流行病学史、临床症状、实验室检测和影像学检查结果等，诊断为确诊病例。\n' +
          '\n' +
          '病例110—病例125，居住于浦东新区，病例126—病例151，居住于黄浦区，病例152—病例172，居住于徐汇区，病例173—病例176，居住于长宁区，病例177—病例184，居住于静安区，病例185—病例189，居住于普陀区，病例190—病例197，居住于虹口区，病例198—病例218，居住于杨浦区，病例219—病例230，居住于闵行区，病例231—病例248，居住于宝山区，病例249—病例252，居住于嘉定区，病例253—病例258，居住于松江区，病例259、病例260，居住于青浦区，为此前报告的本土无症状感染者。经市级专家会诊，综合流行病学史、临床症状、实验室检测和影像学检查结果等，诊断为确诊病例。\n' +
          '\n' +
          '2022年5月3日0—24时，上海新增本土死亡16例。平均年龄82.9岁，最小年龄64岁，最大年龄99岁。16位患者均合并有严重的多脏器慢性基础疾病及恶性肿瘤，包括慢性淋巴细胞性白血病、肺癌合并咯血、冠心病、心功能不全、急性冠脉综合征、高血压3级（极高危）、脑梗死及后遗症、帕金森病、阿尔茨海默病、糖尿病、肝硬化失代偿伴急性上消化道大出血等。患者入院后，原发疾病加重，经抢救无效死亡。死亡的直接原因均为基础疾病。\n' +
          '\n' +
          '2022年5月3日0—24时，上海新增本土无症状感染者4722例。\n' +
          '\n' +
          '无症状感染者1—无症状感染者833，居住于浦东新区，无症状感染者834—无症状感染者1710，居住于黄浦区，无症状感染者1711—无症状感染者2045，居住于徐汇区，无症状感染者2046—无症状感染者2137，居住于长宁区，无症状感染者2138—无症状感染者2685，居住于静安区，无症状感染者2686—无症状感染者2739，居住于普陀区，无症状感染者2740—无症状感染者3084，居住于虹口区，无症状感染者3085—无症状感染者3472，居住于杨浦区，无症状感染者3473—无症状感染者3709，居住于闵行区，无症状感染者3710—无症状感染者4289，居住于宝山区，无症状感染者4290—无症状感染者4459，居住于嘉定区，无症状感染者4460—无症状感染者4463，居住于金山区，无症状感染者4464—无症状感染者4516，居住于松江区，无症状感染者4517—无症状感染者4557，居住于青浦区，无症状感染者4558—无症状感染者4562，居住于奉贤区，无症状感染者4563—无症状感染者4660，居住于崇明区，均为上海市闭环隔离管控人员，其间新冠病毒核酸检测结果异常，经疾控中心复核结果为阳性，诊断为无症状感染者。\n' +
          '\n' +
          '无症状感染者4661，居住于浦东新区，无症状感染者4662—无症状感染者4696，居住于黄浦区，无症状感染者4697、无症状感染者4698，居住于徐汇区，无症状感染者4699—无症状感染者4702，居住于长宁区，无症状感染者4703、无症状感染者4704，居住于虹口区，无症状感染者4705—无症状感染者4710，居住于杨浦区，无症状感染者4711—无症状感染者4716，居住于宝山区，无症状感染者4717，居住于嘉定区，无症状感染者4718—无症状感染者4720，居住于松江区，无症状感染者4721，居住于奉贤区，无症状感染者4722，居住于崇明区，在风险人群筛查中发现新冠病毒核酸检测结果异常，即被隔离管控。经疾控中心复核结果为阳性，诊断为无症状感染者。\n' +
          '\n' +
          '2022年5月3日0—24时，通过口岸联防联控机制，上海报告3例新增境外输入新冠肺炎确诊病例。病例1—病例33，居住于浦东新区，病例34，居住于黄浦区，病例35—病例39，居住于徐汇区，病例40、病例41，居住于长宁区，病例42—病例50，居住于静安区，病例51—病例53，居住于普陀区，病例54—病例56，居住于虹口区，病例57—病例62，居住于杨浦区，病例63—病例65，居住于闵行区，病例66—病例81，居住于宝山区，病例82—病例108，居住于松江区，均为上海市闭环隔离管控人员，其间新冠病毒核酸检测结果异常，经疾控中心复核结果为阳性。经市级专家会诊，综合流行病学史、临床症状、实验室检测和影像学检查结果等，诊断为确诊病例。\n' +
          '\n' +
          '病例109，居住于松江区，在风险人群筛查中发现新冠病毒核酸检测结果异常，即被隔离管控。经疾控中心复核结果为阳性。经市级专家会诊，综合流行病学史、临床症状、实验室检测和影像学检查结果等，诊断为确诊病例。\n' +
          '\n' +
          '病例110—病例125，居住于浦东新区，病例126—病例151，居住于黄浦区，病例152—病例172，居住于徐汇区，病例173—病例176，居住于长宁区，病例177—病例184，居住于静安区，病例185—病例189，居住于普陀区，病例190—病例197，居住于虹口区，病例198—病例218，居住于杨浦区，病例219—病例230，居住于闵行区，病例231—病例248，居住于宝山区，病例249—病例252，居住于嘉定区，病例253—病例258，居住于松江区，病例259、病例260，居住于青浦区，为此前报告的本土无症状感染者。经市级专家会诊，综合流行病学史、临床症状、实验室检测和影像学检查结果等，诊断为确诊病例。\n' +
          '\n' +
          '2022年5月3日0—24时，上海新增本土死亡16例。平均年龄82.9岁，最小年龄64岁，最大年龄99岁。16位患者均合并有严重的多脏器慢性基础疾病及恶性肿瘤，包括慢性淋巴细胞性白血病、肺癌合并咯血、冠心病、心功能不全、急性冠脉综合征、高血压3级（极高危）、脑梗死及后遗症、帕金森病、阿尔茨海默病、糖尿病、肝硬化失代偿伴急性上消化道大出血等。患者入院后，原发疾病加重，经抢救无效死亡。死亡的直接原因均为基础疾病。\n' +
          '\n' +
          '2022年5月3日0—24时，上海新增本土无症状感染者4722例。\n' +
          '\n' +
          '无症状感染者1—无症状感染者833，居住于浦东新区，无症状感染者834—无症状感染者1710，居住于黄浦区，无症状感染者1711—无症状感染者2045，居住于徐汇区，无症状感染者2046—无症状感染者2137，居住于长宁区，无症状感染者2138—无症状感染者2685，居住于静安区，无症状感染者2686—无症状感染者2739，居住于普陀区，无症状感染者2740—无症状感染者3084，居住于虹口区，无症状感染者3085—无症状感染者3472，居住于杨浦区，无症状感染者3473—无症状感染者3709，居住于闵行区，无症状感染者3710—无症状感染者4289，居住于宝山区，无症状感染者4290—无症状感染者4459，居住于嘉定区，无症状感染者4460—无症状感染者4463，居住于金山区，无症状感染者4464—无症状感染者4516，居住于松江区，无症状感染者4517—无症状感染者4557，居住于青浦区，无症状感染者4558—无症状感染者4562，居住于奉贤区，无症状感染者4563—无症状感染者4660，居住于崇明区，均为上海市闭环隔离管控人员，其间新冠病毒核酸检测结果异常，经疾控中心复核结果为阳性，诊断为无症状感染者。\n' +
          '\n' +
          '无症状感染者4661，居住于浦东新区，无症状感染者4662—无症状感染者4696，居住于黄浦区，无症状感染者4697、无症状感染者4698，居住于徐汇区，无症状感染者4699—无症状感染者4702，居住于长宁区，无症状感染者4703、无症状感染者4704，居住于虹口区，无症状感染者4705—无症状感染者4710，居住于杨浦区，无症状感染者4711—无症状感染者4716，居住于宝山区，无症状感染者4717，居住于嘉定区，无症状感染者4718—无症状感染者4720，居住于松江区，无症状感染者4721，居住于奉贤区，无症状感染者4722，居住于崇明区，在风险人群筛查中发现新冠病毒核酸检测结果异常，即被隔离管控。经疾控中心复核结果为阳性，诊断为无症状感染者。\n' +
          '\n' +
          '2022年5月3日0—24时，通过口岸联防联控机制，上海报告3例新增境外输入新冠肺炎确诊病例。'
    }
  }
}
</script>

<style scoped>

/* From uiverse.io by @alexreyes091 */
.card {
  width: 100%;

  background: rgb(236, 236, 236);
  box-shadow: rgba(0, 0, 0, 0.4) 0px 2px 4px, rgba(0, 0, 0, 0.3) 0px 7px 13px -3px, rgba(0, 0, 0, 0.2) 0px -3px 0px inset;
}

.card__content {
  font-size: small;

}


#note-content{
  margin-top: 20px;
  height: 470px;
  background-color: white;
  border-right: 3px solid #444444;
  border-bottom: 3px solid #444444;
  padding: 10px;
  font-size: small;
}

/* From uiverse.io by @ke1221 */
#find_file {
  color: white;
  padding: 0.7em 1.7em;
  font-size: 10px;
  border-radius: 0.5em;
  background: #3d405b;
  border: 1px solid #e8e8e8;
  transition: all .3s;
}

#find_file:active {
  color: #666;
  box-shadow: inset 4px 4px 12px #c5c5c5,
  inset -4px -4px 12px #ffffff;
}

/* From uiverse.io by @NorthFishHasNa */
#comment-btn {
  display: inline-block;
  border-radius: 4px;
  background-color: #F5F5F7;
  border: none;
  color: #3d405b;
  text-align: center;
  font-size: 10px;
  padding: 10px;
  width: 100px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

#comment-btn span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

#comment-btn span:after {
  content: '»';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -15px;
  transition: 0.5s;
}

#comment-btn:hover span {
  padding-right: 15px;
}

#comment-btn:hover span:after {
  opacity: 1;
  right: 0;
}
</style>