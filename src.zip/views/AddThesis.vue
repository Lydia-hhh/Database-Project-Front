<template>



  <div style="background-color: #F5F5F7">
  <div style="width: 90%;margin: 0 5%">

    <el-drawer title="填写论文信息" :before-close="handleClose" :visible.sync="drawer" :direction="direction" style="width: 60%;margin-left: 20%;height: 1820px">

      <template #default>
        <div>
              <el-form label-width="120px" style="width: 80%" size="small">
                <el-form-item label="标题">
                  <el-input/>
                </el-form-item>

                <el-form-item label="作者">
                  <el-input/>
                </el-form-item>

                <el-form-item label="会议">
                  <el-input/>
                </el-form-item>

                <!--时间选择器-->
                <el-form-item label="出版时间">
                  <el-input/>
                </el-form-item>


                <el-form-item label="论文类型">
                  <el-select v-model="thesisType">
                    <el-option
                        v-for="item in typeOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                    />
                  </el-select>
                </el-form-item>

                <el-form-item label="摘要">
                  <textarea></textarea>
                </el-form-item>

                <el-form-item label="原文链接">
                  <el-input/>
                </el-form-item>

                <!--引用是多选-->
                <el-form-item label="添加引用">
                  <el-select v-model="thesisType">
                    <el-option
                        v-for="item in typeOptions"
                        :key="item.value"
                        :label="item.label"
                        :value="item.value"
                    />
                  </el-select>
                </el-form-item>
              </el-form>
        </div>
        <div style="height: 10px"></div>
        <div style="width: 100%;text-align: center">

          <button id="button-save" @click="drawer=!drawer">
            <span class="button_top"> 保存
            </span>
          </button>
        </div>
        <div style="height: 20px"></div>

      </template>
    </el-drawer>

    <div style="height: 30px"></div>
  <div style="margin-left: 80%">
    <button class="learn-more">
  <span class="circle" aria-hidden="true">
  <span class="icon arrow"></span>
  </span>
      <span class="button-text" @click="drawer=!drawer">填写论文信息</span>
    </button>
  </div>
  <div style="height: 5px"></div>
  <div id="input-blank">
    <Toolbar
        style="border-bottom: 1px solid #ccc"
        :editor="editor"
        :defaultConfig="toolbarConfig"
        :mode="mode"
    />
    <Editor
        style="height: 500px; overflow-y: hidden;"
        v-model="content"
        :defaultConfig="editorConfig"
        :mode="mode"
        @onCreated="onCreated"
    />
  </div>

    <button id="button-2" style="margin-left: 86%" @click="centerDialogVisible = true"> 上传附件
    </button>

  </div>


    <el-dialog
        title="上传附件"
        :visible.sync="centerDialogVisible"
        width="30%"
        center>
      <el-upload
          class="upload-demo"
          action="https://jsonplaceholder.typicode.com/posts/"
          :on-change="handleChange"
          :file-list="fileList">
        <div>

          <button id="button-upload">
          <span class="button_top">
            <el-button size="small">点击上传</el-button>

          </span>
          </button>


        </div>

        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
      </el-upload>



      <span slot="footer" class="dialog-footer">
    <el-button @click="centerDialogVisible = false">取 消</el-button>
    <el-button @click="centerDialogVisible = false">确 定</el-button>
  </span>
    </el-dialog>



  </div>

</template>

<script>

import '@wangeditor/editor/dist/css/style.css'
import { Editor, Toolbar } from '@wangeditor/editor-for-vue'

export default {
  name: "AddThesis",
  components: { Editor, Toolbar },
  data() {
    return {

      centerDialogVisible: false,
      drawer: false,
      direction: 'ttb',
      editor: null,
      content:'',
      thesisType:'',
      toolbarConfig: { },
      editorConfig: { placeholder: '请输入内容...' },
      mode: 'default', // or 'simple'
      typeOptions : [
        {
          value: '理论证明型',
          label: '理论证明型',
        },
        {
          value: '综述型',
          label: '综述型',
        },
        {
          value: '实验型',
          label: '实验型',
        },
        {
          value: '工具型',
          label: '工具型',
        },
        {
          value: '数据集型',
          label: '数据集型',
        },
      ],
      fileList: [{
        name: 'food.jpeg',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }, {
        name: 'food2.jpeg',
        url: 'https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100'
      }]
    }
  },
  methods: {
    onCreated(editor) {
      this.editor = Object.seal(editor) // 一定要用 Object.seal() ，否则会报错
    },
    handleClose(done) {
      this.$confirm('确认关闭？')
          .then(_ => {
            done();
          })
          .catch(_ => {});
    },
    handleChange(file, fileList) {
      this.fileList = fileList.slice(-3);
    }



  },
  mounted() {

  },
  beforeDestroy() {
    const editor = this.editor
    if (editor == null) return
    editor.destroy() // 组件销毁时，及时销毁编辑器
  },

}
</script>

<style scoped>

#button-1{
  background-color: #6a60a9;
  color: white;
  width: 100px;
  height: 40px;
  border-radius: 10px;
}
#button-1:active{
  background-color: #5E30E9;
}/* From uiverse.io */
button {
  position: relative;
  display: inline-block;
  cursor: pointer;
  outline: none;
  border: 0;
  vertical-align: middle;
  text-decoration: none;
  background: transparent;
  padding: 0;
  font-size: inherit;
  font-family: inherit;
}

button.learn-more {
  width: 12rem;
  height: auto;
}

button.learn-more .circle {
  transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
  position: relative;
  display: block;
  margin: 0;
  width: 3rem;
  height: 3rem;
  background: #282936;
  border-radius: 1.625rem;
}

button.learn-more .circle .icon {
  transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
  position: absolute;
  top: 0;
  bottom: 0;
  margin: auto;
  background: #fff;
}

button.learn-more .circle .icon.arrow {
  transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
  left: 0.625rem;
  width: 1.125rem;
  height: 0.125rem;
  background: none;
}

button.learn-more .circle .icon.arrow::before {
  position: absolute;
  content: "";
  top: -0.29rem;
  right: 0.0625rem;
  width: 0.625rem;
  height: 0.625rem;
  border-top: 0.125rem solid #fff;
  border-right: 0.125rem solid #fff;
  transform: rotate(45deg);
}

button.learn-more .button-text {
  transition: all 0.45s cubic-bezier(0.65, 0, 0.076, 1);
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  padding: 0.75rem 0;
  margin: 0 0 0 1.85rem;
  color: #282936;
  font-weight: 700;
  line-height: 1.6;
  text-align: center;
  text-transform: uppercase;
}

button:hover .circle {
  width: 100%;
}

button:hover .circle .icon.arrow {
  background: #fff;
  transform: translate(1rem, 0);
}

button:hover .button-text {
  color: #fff;
}
/* From uiverse.io */
#button-2 {
  --color: #282936;
  font-family: inherit;
  display: inline-block;
  width: 8em;
  height: 2.6em;
  line-height: 2.5em;
  margin: 20px;
  position: relative;
  overflow: hidden;
  border: 2px solid var(--color);
  transition: color .5s;
  z-index: 1;
  font-size: 17px;
  border-radius: 6px;
  font-weight: 500;
  color: var(--color);
}

#button-2:before {
  content: "";
  position: absolute;
  z-index: -1;
  background: var(--color);
  height: 150px;
  width: 200px;
  border-radius: 50%;
}

#button-2:hover {
  color: #fff;
}

#button-2:before {
  top: 100%;
  left: 100%;
  transition: all .7s;
}

#button-2:hover:before {
  top: -30px;
  left: -30px;
}

#button-2:active:before {
  background: #282936;
  transition: background 0s;
}
#input-blank{
  border-right: 2px solid #282936;
  border-bottom: 2px solid #282936;
}

/* From uiverse.io by @Voxybuns */
#button-save {
  /* Variables */
  --button_radius: 0.75em;
  --button_color: #e8e8e8;
  --button_outline_color: #000000;
  font-size: 14px;
  font-weight: bold;
  border: none;
  border-radius: var(--button_radius);
  background: var(--button_outline_color);
}

.button_top {
  display: block;
  box-sizing: border-box;
  border: 2px solid var(--button_outline_color);
  border-radius: var(--button_radius);
  padding: 0.75em 1.5em;
  background: var(--button_color);
  color: var(--button_outline_color);
  transform: translateY(-0.2em);
  transition: transform 0.1s ease;
}

#button-save:hover .button_top {
  /* Pull the button upwards when hovered */
  transform: translateY(-0.33em);
}

#button-save:active .button_top {
  /* Push the button downwards when pressed */
  transform: translateY(0);
}

/* From uiverse.io by @Voxybuns */
#button-upload {
  /* Variables */
  --button_radius: 0.75em;
  --button_color: #e8e8e8;
  --button_outline_color: #000000;
  font-size: 10px;
  font-weight: bold;
  border: none;
  border-radius: var(--button_radius);
  background: var(--button_outline_color);
}

#button-upload.button_top {
  display: block;
  box-sizing: border-box;
  border: 2px solid var(--button_outline_color);
  border-radius: var(--button_radius);
  padding: 0.75em 1.5em;
  background: var(--button_color);
  color: var(--button_outline_color);
  transform: translateY(-0.2em);
  transition: transform 0.1s ease;
}

#button-upload:hover .button_top {
  /* Pull the button upwards when hovered */
  transform: translateY(-0.33em);
}

#button-upload:active .button_top {
  /* Push the button downwards when pressed */
  transform: translateY(0);
}
</style>