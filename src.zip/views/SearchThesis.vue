<template xmlns="http://www.w3.org/1999/html">

  <div style="background-color:  #F5F5F7">
  <!--搜索框-->
  <div style="margin-left: 20%;margin-top: 20px;width: 80%">
    <div style="display: inline-block">


      <el-tooltip placement="bottom" effect="light">
        <div slot="content">
          作者：{{selectCondition.author}}<br/>
          发布人：{{selectCondition.uploader}}<br/>
          会议：{{selectCondition.conference}}<br/>
          论文类型：{{selectCondition.essay_type}}<br/>
          研究方向：{{selectCondition.orientation}}<br/>
        </div>
        <el-button type="prime" icon="el-icon-search" @click="centerDialogVisible = true">筛选 </el-button>
      </el-tooltip>
    </div>

    <div style="display: inline-block;width: 55%">

      <el-input id="input" v-model="input">
      </el-input>

    </div>

    <div style="display: inline-block">

        <el-button type="primary" icon="el-icon-search">查询 </el-button>


    </div>


  </div>

    <!--搜索框-->

<div style="height: 20px"></div>
    <!--展示内容-->
    <div style="height: 610px; ">
      <el-scrollbar style="height: 100%;overflow-x: hidden;">
        <div v-for="(item,index) in tableData">

          <ThesisInfo  v-bind:item="item"></ThesisInfo>
        </div>

      </el-scrollbar>

    </div>


    <!--展示内容-->

    <!--分页-->
    <div style="width: 60%;margin-left: 20%">
      <el-pagination style="margin: 0 auto"
          v-model:currentPage="currentPage4"
          v-model:page-size="pageSize4"
          :page-sizes="[5, 10, 15 , 20]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="400"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
      />
    </div>
    <!--分页-->



    <el-dialog
        title="筛选条件"
        :visible.sync="centerDialogVisible"
        width="30%"
        center>

      <el-form label-width="120px"

               style="width: 80%">
        <el-form-item label="作者">
          <el-input v-model="selectCondition.author"/>
        </el-form-item>

        <el-form-item  label="发布人">
          <el-input v-model="selectCondition.uploader" />
        </el-form-item>

        <el-form-item  label="会议">
          <el-input v-model="selectCondition.conference"/>
        </el-form-item>

        <el-form-item label="论文类型">
          <el-select v-model="selectCondition.essay_type">
            <el-option
                v-for="item in typeOptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="研究方向">
          <div class="example-block">
            <el-cascader v-model="selectCondition.orientation" :options="directionOptions" @change="handleChange" />
          </div>

        </el-form-item>


      </el-form>
      <span slot="footer" class="dialog-footer">
    <el-button @click="centerDialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="centerDialogVisible = false">确 定</el-button>
  </span>
    </el-dialog>

  </div>





</template>

<script>
// import {Search} from '@element-plus/icons-vue'
import {directionOptions} from "@/utils/data/directionData";
import ThesisInfo from "@/components/ThesisInfo";

export default {
  name: "SearchThesis",
  components:{
    ThesisInfo,
    // Search,
    directionOptions
  },
  data(){
    return{
      input:'',
      selectCondition:{
        author:'',
        uploader:'',
        conference:'',
        essay_type:'',
        orientation:'',


      },
      centerDialogVisible: false,
      currentPage4:1,
      pageSize4:3,
      typeOptions : [
        {
          value: '理论证明型',
          label: '理论证明型',
        },
        {
          value: '综述型',
          label: '综述型',
        },
        {
          value: '实验型',
          label: '实验型',
        },
        {
          value: '工具型',
          label: '工具型',
        },
        {
          value: '数据集型',
          label: '数据集型',
        },
      ],
      directionOptions:directionOptions,
      tableData : [
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          abstract:'以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          abstract:'以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          abstract:'以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          abstract:'以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          abstract:'以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          abstract:'以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          abstract:'以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤'
        },
        {
          title:'自然语言处理新范式：基于预训练模型的方法',
          author:'车万翔 刘挺',
          periodical:'中兴通讯技术',
          date:'2016-05-02',
          type:'计算机软件及计算机应用',
          abstract:'以BERT、GPT为代表的、基于超大规模文本数据的预训练语言模型能够充分利用大模型、' +
              '大数据和大计算，使几乎所有自然语言处理任务性能都得到显著提升，在一些数据集上达到甚至超过人类水平，' +
              '已成为自然语言处理的新范式。认为未来自然语言处理，乃至整个人工智能领域，将沿着“同质化”和“规模化”的道路继续前进，' +
              '并将融入多模态数据、具身行为数据、社会交互数据等更多的“知识”源，从而为实现真正的通用人工智能铺平道路。',
          uploader:'刘大锤'
        }]

    }
  },
  methods:{
    handleChange(e){
      console.log(e);
    },
    handleSizeChange(){

    },
    handleCurrentChange(){

    }


  }

}
</script>

<style scoped>
#input{
  height: 2.4em;
   background-color:#A370F0 ;
}

/* From uiverse.io by @adamgiebl */
.cssbuttons-io-button {
  background: #A370F0;
  color: white;
  font-family: inherit;
  padding: 0.35em;
  padding-left: 1.2em;
  font-size: 17px;
  font-weight: 500;
  border-bottom-right-radius: 0.9em;
  border-top-right-radius: 0.9em;
  border: none;
  letter-spacing: 0.05em;
  display: flex;
  align-items: center;
  box-shadow: inset 0 0 1.6em -0.6em #714da6;
  overflow: hidden;
  position: relative;
  height: 2.4em;
  padding-right: 3.3em;
}

.cssbuttons-io-button .icon {
  background: white;
  margin-left: 1em;
  position: absolute;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 2.2em;
  width: 2.2em;
  border-radius: 0.7em;
  box-shadow: 0.1em 0.1em 0.6em 0.2em #7b52b9;
  right: 0.3em;
  transition: all 0.3s;
}

.cssbuttons-io-button:hover .icon {
  width: calc(100% - 0.6em);
}

.cssbuttons-io-button .icon svg {
  width: 1.1em;
  transition: transform 0.3s;
  color: #7b52b9;
}

.cssbuttons-io-button:hover .icon svg {
  transform: translateX(0.1em);
}

.cssbuttons-io-button:active .icon {
  transform: scale(0.95);
}

</style>