<template>
<div style="height: 50px;line-height: 50px;border-bottom: 1px solid #ccc;display: flex;background-color: #409EFF">
  <div style="width:200px;font-size: 20px;color: white;padding-left: 20px">用户界面</div>
  <div style="flex: 1;"></div>
  <div style="width: 100px">
    <el-button>退出登录</el-button>
  </div>
</div>
</template>

<script>
export default {
  name: "Header"
}
</script>

<style scoped>

</style>